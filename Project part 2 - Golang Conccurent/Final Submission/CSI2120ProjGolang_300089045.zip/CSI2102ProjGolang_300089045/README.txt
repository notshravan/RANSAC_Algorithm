Name: Shravan Vyas
Student Number: 300089045
Csi 2120 Project 2: Winter 2023

Note: Original XYZ files are contained within the folder "cloudorigin".
This directory contains all the xyz files requested and produced by the run algorithm.


Project was built using GOLAND