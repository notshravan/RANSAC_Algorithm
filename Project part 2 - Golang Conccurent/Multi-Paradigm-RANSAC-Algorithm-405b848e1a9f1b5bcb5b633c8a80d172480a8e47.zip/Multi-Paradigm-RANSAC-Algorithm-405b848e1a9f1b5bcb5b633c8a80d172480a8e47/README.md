
Multi-Paradigm RANSAC Algorithm