Name: Shravan Vyas
Student ID: 300089045
Course: Csi 2120
Project Prolog Part 4
All test cases are included in the Project file: PartProlog4.pl
